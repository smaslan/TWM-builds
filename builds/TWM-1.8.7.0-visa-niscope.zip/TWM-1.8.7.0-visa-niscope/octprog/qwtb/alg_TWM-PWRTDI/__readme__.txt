In process of conversion from PWRTEST to JV's time-integration wattmeter.

todo:
- testing
- verify loading_correction!!!! Not calculating uncertainty properly? Fixed for single-ended mode, need to check diff mode